# GemmaCare: Official 60-Second Video & Presentation Pitch Guide

> **Project Title**: GemmaCare — Fail-Safe Multimodal Clinical System  
> **Tagline**: *Zero-Hallucination AI. Sub-Second Safety.*  
> **Target Duration**: 60 Seconds (142 Words)

---

## 📜 Clean Teleprompter Script

Doctors today spend nearly half their workday clicking through messy EHR screens just to prepare for a 15-minute visit. But using standard AI chatbots in healthcare carries a fatal flaw: probabilistic hallucination.

Meet GemmaCare: a fail-safe multimodal clinical system powered by MedGemma 1.5 4B. GemmaCare solves the hallucination problem by splitting safety from reasoning into a Dual-Engine Architecture.

First, a lightning-fast Python engine checks critical vital signs in under one millisecond with zero LLM dependency. Simultaneously, MedGemma ingests patient histories, lab OCR text, and radiology images—grounded by Vertex AI RAG—to deliver a precise, 1-page Triage Brief in under 15 seconds.

Crucially, GemmaCare never makes final decisions alone. The clinician reviews cited policy sources, edits recommendations if needed, and approves the record with a single tap.

GemmaCare saves doctors up to 75% of chart prep time on every visit—combining Zero-Hallucination AI with Sub-Second Safety. Thank you!

---

## ⏱️ Word-by-Word Script with Cues & Visual Sync

| Time | Script Section | Delivery Cues | Visual & Screen Sync |
| :--- | :--- | :--- | :--- |
| **0:00 - 0:12** | *"Doctors today spend nearly half their workday clicking through messy EHR screens just to prepare for a 15-minute visit. But using standard AI chatbots in healthcare carries a fatal flaw: **probabilistic hallucination**."* | Serious, empathetic tone. Emphasize **probabilistic hallucination**. | **Visual**: Show a doctor overwhelmed by 10+ open EHR browser tabs vs. a glowing red warning icon. |
| **0:12 - 0:25** | *"Meet **GemmaCare: a fail-safe multimodal clinical system** powered by MedGemma 1.5 4B. GemmaCare solves the hallucination problem by splitting safety from reasoning into a **Dual-Engine Architecture**."* | Confident, upbeat transition. High energy on **GemmaCare**. | **Visual**: Show GemmaCare Logo + Dual-Engine architectural diagram (Python Safety Engine + MedGemma 1.5 4B). |
| **0:25 - 0:40** | *"First, a lightning-fast Python engine checks critical vital signs in **under one millisecond** with zero LLM dependency. Simultaneously, MedGemma ingests patient histories, lab OCR text, and radiology images—grounded by Vertex AI RAG—to deliver a precise, 1-page Triage Brief in **under 15 seconds**."* | Clear, rhythmic pace. Stress **under one millisecond** and **under 15 seconds**. | **Visual**: Screen capture of Clinician Workspace: highlight yellow hypoxia alert ($< 1\text{ms}$) + chest X-ray image feeding into 1-page summary. |
| **0:40 - 0:52** | *"Crucially, GemmaCare never makes final decisions alone. The clinician reviews cited policy sources, edits recommendations if needed, and approves the record with a single tap."* | Authoritative, reassuring tone. Focus on **single tap**. | **Visual**: Zoom in on **Approve & Commit Record** button being clicked, showing cited policy documents. |
| **0:52 - 1:00** | *"GemmaCare saves doctors up to **75% of chart prep time** on every visit—combining **Zero-Hallucination AI with Sub-Second Safety**. Thank you!"* | Strong, memorable finish with a smile. | **Visual**: Show metric card (75% Time Savings) + final slide displaying: *"Zero-Hallucination AI. Sub-Second Safety."* |

---

## 💬 Anticipated Judge Questions & 10-Second Answers

### Q1: *"How do you prevent MedGemma from hallucinating treatment plans?"*
> **Answer**: *"We anchor MedGemma using Vertex AI RAG Engine against verified hospital policy guidelines in AlloyDB ScaNN. Every statement requires a verifiable source citation; unsupported statements are automatically stripped."*

### Q2: *"What happens if the LLM endpoint or network goes down during an emergency?"*
> **Answer**: *"Patient safety is never compromised. Our Zero-LLM Deterministic Safety Engine runs in pure Python in under 1 millisecond independently of LLM availability, catching critical vital sign red flags instantly."*

### Q3: *"How does this integrate with real hospital EHR systems like Epic or Cerner?"*
> **Answer**: *"GemmaCare is built on Hexagonal Architecture. All data access goes through our `PatientDataPort` interface. Connecting to Epic or Cerner simply requires plugging in their FHIR adapter without modifying any core clinical logic."*
