"""
CareFlow 360 - Zero-LLM Deterministic Safety Engine
Pure Python (safety_rules.py)
Evaluates vital sign thresholds against FHIR R4 observation resources in < 1ms.
"""

from typing import Dict, Any, List, Optional
import time

class DeterministicSafetyEngine:
    def __init__(self):
        self.version = "2.4.0-FHIR-R4"

    def evaluate_fhir_observations(self, patient_fhir: Dict[str, Any], observations: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Evaluates synthetic FHIR R4 patient records for acute safety flags in < 1ms.
        """
        start_time = time.perf_counter()
        alerts = []
        patient_age = patient_fhir.get("age", 50)
        
        for obs in observations:
            code = obs.get("code", "")
            value = obs.get("value", 0)
            
            # Rule #104: Geriatric SpO2 Hypoxia Guardrail
            if code == "2708-6" or "SpO2" in obs.get("display", ""):
                if value < 90.0:
                    alerts.append({
                        "rule_id": "RULE-104",
                        "severity": "WARNING",
                        "title": "Geriatric Oxygen Saturation Guardrail Intercept",
                        "message": f"SpO2 measured at {value}% on ambient air. Protocol mandates immediate supplemental O2 initiation prior to full chart review.",
                        "action": "Initiate O2 protocol at 2L/min via nasal cannula."
                    })
                    
            # Rule #101: Pediatric High Fever Guardrail
            if code == "8310-5" or "BodyTemp" in obs.get("display", ""):
                if patient_age <= 5 and value >= 38.5:
                    alerts.append({
                        "rule_id": "RULE-101",
                        "severity": "CRITICAL",
                        "title": "Pediatric High Fever Critical Intercept",
                        "message": f"Pediatric fever measured at {value}°C paired with petechial eruption risk. Immediate resuscitation transfer required.",
                        "action": "Immediate transfer to Resuscitation Bay & draw blood cultures."
                    })
                    
            # Rule #108: Hypertensive Crisis Guardrail
            if code == "8480-6" or "SystolicBP" in obs.get("display", ""):
                if value >= 180.0:
                    alerts.append({
                        "rule_id": "RULE-108",
                        "severity": "CRITICAL",
                        "title": "Hypertensive Crisis Safety Intercept",
                        "message": f"Systolic Blood Pressure measured at {value} mmHg. STAT ECG and ACS protocol active.",
                        "action": "Administer Sublingual Nitroglycerin & STAT ECG."
                    })

        elapsed_ms = (time.perf_counter() - start_time) * 1000.0
        
        return {
            "status": "EVALUATED",
            "execution_time_ms": round(elapsed_ms, 3),
            "alerts": alerts,
            "passed": len([a for a in alerts if a["severity"] == "CRITICAL"]) == 0
        }

if __name__ == "__main__":
    engine = DeterministicSafetyEngine()
    test_obs = [{"code": "2708-6", "display": "SpO2", "value": 88.5}]
    res = engine.evaluate_fhir_observations({"age": 68}, test_obs)
    print("Execution Result:", res)
